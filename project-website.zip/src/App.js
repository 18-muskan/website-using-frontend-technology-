import React, { useState } from "react";
import "./styles.css";

const root = React.createElement;

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [showSubscribeForm, setShowSubscribeForm] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState("");
  const [showContactForm, setShowContactForm] = useState(false);
  const [showCustomMealForm, setShowCustomMealForm] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [suggestion, setSuggestion] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    setLoggedIn(true);
  };

  const handleSubscribe = (plan) => {
    setSelectedPlan(plan);
    setShowSubscribeForm(true);
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setShowSubscribeForm(false);
    setShowPayment(true);
  };

  const handleSuggestion = () => {
    alert("Thank you for your feedback!");
    setSuggestion("");
  };

  if (!loggedIn) {
    return root("div", { className: "login-page" },
      root("h2", {}, "Welcome to Mezbaan - Desi Meals Delivered"),
      root("form", { onSubmit: handleLogin, className: "login-form" }, 
        root("input", { placeholder: "Username", required: true }),
        root("input", { placeholder: "Password", type: "password", required: true }),
        root("button", { type: "submit" }, "Login")
      )
    );
  }

  return root("div", { className: "app" },
    root("header", { className: "header" },
      root("h1", {}, "🍽️ Mezbaan - Desi Meals Delivered"),
      root("nav", {},
        root("button", { onClick: () => setLoggedIn(false) }, "Logout"),
        root("button", { onClick: () => setShowContactForm(true) }, "Contact Us")
      )
    ),

    root("section", { className: "plans-section" },
      root("h2", {}, "Choose Your Meal Plan"),
      ["Daily", "Weekly", "Monthly"].map(plan =>
        root("div", { className: "plan-card", key: plan },
          root("h3", {}, `${plan} Plan`),
          root("p", {}, `Enjoy fresh desi meals every ${plan.toLowerCase()}!`),
          root("ul", {}, [
            "Chicken Biryani", "Daal Chawal", "Karahi", "Paratha Roll", "Chai", "Raita", "Cold Drink"
          ].map((item, i) => root("li", { key: i }, item))),
          root("p", { className: "price-tag" }, plan === "Daily" ? "Rs. 300" : plan === "Weekly" ? "Rs. 1800" : "Rs. 6500"),
          root("button", {
            className: "subscribe-btn",
            onClick: () => handleSubscribe(plan)
          }, `Subscribe to ${plan}`)
        )
      )
    ),

    showSubscribeForm && root("form", {
      className: "subscribe-form",
      onSubmit: handleFormSubmit
    },
      root("h3", {}, `Subscribe to ${selectedPlan} Plan`),
      root("input", { placeholder: "Full Name", required: true }),
      root("input", { placeholder: "Address", required: true }),
      root("input", { placeholder: "City", required: true }),
      root("button", { type: "submit" }, "Proceed to Payment")
    ),

    showPayment && root("div", { className: "payment-ui" },
      root("h4", {}, "Select Payment Method"),
      ["Cash on Delivery", "Credit/Debit Card", "UPI"].map((method, i) =>
        root("div", { key: i },
          root("input", { type: "radio", id: method, name: "payment" }),
          root("label", { htmlFor: method }, method)
        )
      ),
      root("button", {
        onClick: () => {
          alert("Subscription confirmed!");
          setShowPayment(false);
        }
      }, "Confirm Order")
    ),

    root("section", { className: "featured-section" },
      root("h2", {}, "Want Something Different?"),
      root("p", {}, "Choose extra dishes or customize your meal plan."),
      root("button", {
        onClick: () => setShowCustomMealForm(true)
      }, "Customize Meal")
    ),

    showCustomMealForm && root("form", {
      className: "custom-meal-form",
      onSubmit: (e) => {
        e.preventDefault();
        alert("Custom order placed successfully!");
        setShowCustomMealForm(false);
      }
    },
      root("textarea", {
        placeholder: "Mention your dietary needs or custom order...",
        required: true
      }),
      root("button", { type: "submit" }, "Submit Request")
    ),

    root("section", { className: "rating-section" },
      root("h3", {}, "Suggestions & Ratings"),
      root("textarea", {
        value: suggestion,
        onChange: (e) => setSuggestion(e.target.value),
        placeholder: "Share your feedback..."
      }),
      root("button", { onClick: handleSuggestion }, "Submit")
    ),

    showContactForm && root("form", {
      className: "contact-form",
      onSubmit: (e) => {
        e.preventDefault();
        alert("We'll get back to you soon!");
        setShowContactForm(false);
      }
    },
      root("h3", {}, "Contact Us"),
      root("input", { placeholder: "Your Name", required: true }),
      root("input", { placeholder: "Email Address", required: true }),
      root("textarea", { placeholder: "Your Message", required: true }),
      root("button", { type: "submit" }, "Send Message")
    )
  );
}
